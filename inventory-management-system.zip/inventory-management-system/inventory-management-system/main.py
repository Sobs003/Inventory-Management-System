import getpass

#User-Managements
class UserMgmt:
    users_db = {
        'SobAdmin': {'password': 'Sob111', 'role': 'Admin'},
        'TestUser': {'password': 'Test123', 'role': 'User'}
    }

    def __init__(self, user_name, password):
        self.user_name = user_name
        self.password = password
        self.role = None

    def authenticate(self):
        user_info = UserMgmt.users_db.get(self.user_name)
        if user_info and user_info['password'] == self.password:
            self.role = user_info['role']
            return True
        return False

    def has_permission(self, action):
        return self.role == 'Admin' if action in ['add', 'edit', 'delete'] else True
    
#OPP-Implementations
class Product:
    product_parameter = {}

    def __init__(self, product_id, name, category, price, stock_quantity):
        self.product_id = product_id
        self.name = name
        self.category = category
        self.price = price
        self.stock_quantity = stock_quantity

    @staticmethod
    def add_product(product_id, name, category, price, stock_quantity):
        if product_id in Product.product_parameter:
            print("ProductID already exist")
        else:
            Product.product_parameter[product_id] = Product(product_id, name, category, price, stock_quantity)
            print(f"Product '{name}' added Successfully!")

    @staticmethod
    def edit_product(product_id, name=None, category=None, price=None, stock_quantity=None):
        product = Product.product_parameter.get(product_id)
        if product:
            if name:
                product.name = name
            if category:
                product.category = category
            if price:
                product.price = price
            if stock_quantity is not None:
                product.stock_quantity = stock_quantity
            print("Product Update Successfully!")
        else:
            print("Product didnot found")

    @staticmethod
    def delete_product(product_id):
        if product_id in Product.product_parameter:
            del Product.product_parameter[product_id]
            print("Product delete successfully!")
        else:
            print("Product didnot found.")

    @staticmethod
    def view_products():
        if Product.product_parameter:
            for product in Product.product_parameter.values():
                print(vars(product))
        else:
            print("No products available.")

    @staticmethod
    def search_product(name=None, category=None):
        results = [prod for prod in Product.product_parameter.values()
                   if (name and prod.name == name) or (category and prod.category == category)]
        if results:
            for result in results:
                print(vars(result))
        else:
            print("No matching products found.")

    @staticmethod
    def adjust_stock(product_id, quantity):
        product = Product.product_parameter.get(product_id)
        if product:
            product.stock_quantity += quantity
            print(f"Stock adjusted. New stocks quantity are : {product.stock_quantity}")
        else:
            print("Product didnot found.")

    @staticmethod
    def check_stock_levels(threshold=5):
        for product in Product.product_parameter.values():
            if product.stock_quantity <= threshold:
                print(f"Low stock alert for {product.name}!")


#MainApp
def main():
    print("Inventory Management System")
    user_name = input("Enter User Name: ")
    password = getpass.getpass("Enter User Password: ")
    user = UserMgmt(user_name, password)
    
    if not user.authenticate():
        print("Invalid Credientials.")
        return
    
    print(f"Login Successful! Role: {user.role}")
    
    while True:
        print("\nMain Menu:")
        print("1. Add Product")
        print("2. Edit Product")
        print("3. Delete Product")
        print("4. View Products")
        print("5. Search Products")
        print("6. Adjust Stock")
        print("7. Check Low Stock Levels")
        print("0. Exit")
        
        choice = input("Enter choice: ")
        
        if choice == '1' and user.has_permission('add'):
            try:
                product_id = input("Enter Product ID: ")
                name = input("Enter Product Name: ")
                category = input("Enter Category: ")
                price = float(input("Enter Price: "))
                stock_quantity = int(input("Enter Stock Quantities: "))
                Product.add_product(product_id, name, category, price, stock_quantity)
            except ValueError:
                print("Invalid input! Price should be a number & stock quantity should be an integer.")
        
        elif choice == '2' and user.has_permission('edit'):
            try:
                product_id = input("Enter Product ID: ")
                name = input("Enter New Name (leave blank in case you didn't need change): ") or None
                category = input("Enter New Category (leave blank in case you didn't need change): ") or None
                price = input("Enter New price (leave blank in case you didn't need change): ")
                stock_quantity = input("Enter New stock quantity (leave blank in case you didn't need change): ")
                Product.edit_product(product_id, name, category, float(price) if price else None,
                                     int(stock_quantity) if stock_quantity else None)
            except ValueError:
                print("Invalid input! Price should be a number & stock quantity should be an integer.")
        
        elif choice == '3' and user.has_permission('delete'):
            product_id = input("Enter Product ID: ")
            Product.delete_product(product_id)
        
        elif choice == '4':
            Product.view_products()
        
        elif choice == '5':
            name = input("Enter name to search (leave blank in case you didn't need change): ")
            category = input("Enter category to search (leave blank in case you didn't need change): ")
            Product.search_product(name=name if name else None, category=category if category else None)
        
        elif choice == '6':
            try:
                product_id = input("Enter Product ID for stock adjustment: ")
                quantity = int(input("Enter quantity to add/subtract (use minus to reduce): "))
                Product.adjust_stock(product_id, quantity)
            except ValueError:
                print("Invalid input! Quantity should be an integer.")
        
        elif choice == '7':
            threshold = int(input("Enter stock thresholds for low stock alert: "))
            Product.check_stock_levels(threshold)
        
        elif choice == '0':
            print("Exit")
            break
        
        else:
            print("Invalid Choice,Try Again.")

if __name__ == "__main__":
    main()